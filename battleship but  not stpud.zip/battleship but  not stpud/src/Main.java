/*
USE FULLSCREEN FOR BEST EXPERIENCE

*/
import java.util.Arrays;
import java.util.Objects;
import java.util.Scanner;

public class Main {
    Scanner sc = new Scanner(System.in);
    // String input = sc.next();

    public static void main(String[] args){
        Board b = new Board();
        Board c = new Board();
        Scanner sc = new Scanner(System.in);
        String prompt1 = "Pick a spot to place the ship || example- 1(left) (press enter) 5(bottom)";
        boolean play = true;




        Object PrintBoardB = Arrays.toString(b.row0) + "\n" + Arrays.toString(b.row1) + "\n" + Arrays.toString(b.row2) + "\n" + Arrays.toString(b.row3) + "\n" + Arrays.toString(b.row4) + "\n" + Arrays.toString(b.row10);

        Object PrintBoardC = Arrays.toString(c.row0) + "\n" + Arrays.toString(c.row1) + "\n" + Arrays.toString(c.row2) + "\n" + Arrays.toString(c.row3) + "\n" + Arrays.toString(c.row4) + "\n"+ Arrays.toString(c.row10);



        String hit =
                "ooooo ooooo ooooo ooooooooooo  oo  \n" +
                " 888   888   888  88  888  88 8888 \n" +
                " 888ooo888   888      888     8888 \n" +
                " 888   888   888      888      88  \n" +
                "o888o o888o o888o    o888o     oo \n" +
                "\n";


        String miss =
                "              o88                          \n" +
                "oo ooo oooo   oooo   oooooooo8  oooooooo8  \n" +
                " 888 888 888   888  888ooooooo 888ooooooo  \n" +
                " 888 888 888   888          888        888 \n" +
                "o888o888o888o o888o 88oooooo88 88oooooo88  ";


        String title =
                "oooooooooo      o   ooooooooooo ooooooooooo ooooo       ooooooooooo  oooooooo8 ooooo ooooo ooooo oooooooooo   oo  \n" +
                " 888    888    888  88  888  88 88  888  88  888         888    88  888         888   888   888   888    888 8888 \n" +
                " 888oooo88    8  88     888         888      888         888ooo8     888oooooo  888ooo888   888   888oooo88  8888 \n" +
                " 888    888  8oooo88    888         888      888      o  888    oo          888 888   888   888   888         88  \n" +
                "o888ooo888 o88o  o888o o888o       o888o    o888ooooo88 o888ooo8888 o88oooo888 o888o o888o o888o o888o        oo  \n" +
                "                                                                                                                  ";


// title screen, must be opened in full screen or it looks stupid and broken
        System.out.println(title);



    for (int i = 0; i < 1; i++) {
        // System.out.println(Arrays.toString(b.row0) + "\n" + Arrays.toString(b.row1) + "\n" + Arrays.toString(b.row2) + "\n" + Arrays.toString(b.row3) + "\n" + Arrays.toString(b.row4) + "\n" + Arrays.toString(b.row5) + "\n" + Arrays.toString(b.row6) + "\n" + Arrays.toString(b.row7) + "\n" + Arrays.toString(b.row8) + "\n" + Arrays.toString(b.row9) + "\n" + Arrays.toString(b.row10));
        System.out.println(PrintBoardB);
    }

        // System.out.println("player one, do you want your 5 ship horizontal or vertical (h or v)");
   // String tempinput = sc.next();


System.out.println("player one is about to pick their ships");
        for (int i = 0; i < 4; i++) {

            System.out.println(prompt1);
            String yinput = sc.next();
            int xinput = sc.nextInt();


            System.out.println("you have selected y cord " + yinput + " and the x cord " + xinput);
            if (Objects.equals(yinput, "1")) {
                b.row0[xinput] = 8;
                System.out.println(Arrays.toString(b.row0));

            }
            if (Objects.equals(yinput, "2")) {
                b.row1[xinput] = 8;
                System.out.println(Arrays.toString(b.row1));

            }
            if (Objects.equals(yinput, "3")) {
                b.row2[xinput] = 8;
                System.out.println(Arrays.toString(b.row2));

            }
            if (Objects.equals(yinput, "4")) {
                b.row3[xinput] = 8;
                System.out.println(Arrays.toString(b.row3));

            }
            if (Objects.equals(yinput, "5")) {
                b.row4[xinput] = 8;
                System.out.println(Arrays.toString(b.row4));

            }
       // System.out.println(PrintBoardB);
        }
;

        System.out.println("player two is about to pick their ships");
        for (int i = 0; i < 4; i++) {

            System.out.println(prompt1);
            String yinput = sc.next();
            int xinput = sc.nextInt();


            System.out.println("you have selected row " + yinput + " and the x cord " + xinput);
            if (Objects.equals(yinput, "1")) {
                c.row0[xinput] = 8;
                System.out.println(Arrays.toString(c.row0));

            }
            if (Objects.equals(yinput, "2")) {
                c.row1[xinput] = 8;
                System.out.println(Arrays.toString(c.row1));

            }
            if (Objects.equals(yinput, "3")) {
                c.row2[xinput] = 8;
                System.out.println(Arrays.toString(c.row2));

            }
            if (Objects.equals(yinput, "4")) {
                c.row3[xinput] = 8;
                System.out.println(Arrays.toString(c.row3));

            }
            if (Objects.equals(yinput, "5")) {
                c.row4[xinput] = 8;
                System.out.println(Arrays.toString(c.row4));

            }
           // System.out.println(PrintBoardC);
        }
            System.out.println("Player one pick where to shoot");
            String yinput = sc.next();
            int xinput = sc.nextInt();
            System.out.println(PrintBoardB);

    }
}
