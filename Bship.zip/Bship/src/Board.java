public class Board {
    String[] row0;
    String[] row1;
    String[] row2;
    String[] row3;
    String[] row4;
    String[] row5;
    String[] row6;
    String[] row7;
    String[] row8;
    String[] row9;
    String[] row10;
    // String emptySpace = "O";


    public Board() {
        initBoard();
    }

    private void initBoard() {
        row0 = new String[]{"a","o","o", "o", "o", "o", "o", "o", "o", "o", "o"};
        row1 = new String[]{"b", "o", "o", "o", "o", "o", "o", "o", "o", "o", "o"};
        row2 = new String[]{"c","o", "o", "o", "o", "o", "o", "o", "o", "o", "o"};
        row3 = new String[]{"d","o", "o", "o", "o", "o", "o", "o", "o", "o", "o"};
        row4 = new String[]{"e","o", "o", "o", "o", "o", "o", "o", "o", "o", "o"};
        row5 = new String[]{"f","o", "o", "o", "o", "o", "o", "o", "o", "o", "o"};
        row6 = new String[]{"g","o", "o", "o", "o", "o", "o", "o", "o", "o", "o"};
        row7 = new String[]{"h","o", "o", "o", "o", "o", "o", "o", "o", "o", "o"};
        row8 = new String[]{"i","o", "o", "o", "o", "o", "o", "o", "o", "o", "o"};
        row9 = new String[]{"j","o", "o", "o", "o", "o", "o", "o", "o", "o", "o"};
        row10 = new String[]{"k","1","2","3","4","5","6","7","8","9","10"};


    }

/*        for(
    int i = 0;
    i<row0.length;i++)

    {
        row0[i] = emptySpace;
        row1[i] = emptySpace;
        row2[i] = emptySpace;
        row3[i] = emptySpace;
        row4[i] = emptySpace;
        row5[i] = emptySpace;
        row6[i] = emptySpace;
        row7[i] = emptySpace;
        row8[i] = emptySpace;
        row9[i] = emptySpace;


    }
*/


    public void boardDisplay(){
        System.out.println(" ");
        for (int j = 0; j < row0.length; j++){
            System.out.print(row0[j]);
        }
        System.out.println(" ");
        for (int j = 0; j < row1.length; j++){
            System.out.print(row1[j]);
        }
        System.out.println(" ");
        for (int j = 0; j < row2.length; j++){
            System.out.print(row2[j]);
        }
        System.out.println(" ");
        for (int j = 0; j < row3.length; j++) {
            System.out.print(row3[j]);
        }
        System.out.println(" ");
        for (int j = 0; j < row4.length; j++){
            System.out.print(row4[j]);
        }
        System.out.println(" ");
        for (int j = 0; j < row5.length; j++){
            System.out.print(row6[j]);
        }
        System.out.println(" ");
        for (int j = 0; j < row6.length; j++){
            System.out.print(row6[j]);
        }
        System.out.println(" ");
        for (int j = 0; j < row7.length; j++){
            System.out.print(row7[j]);
        }
        System.out.println(" ");
        for (int j = 0; j < row8.length; j++){
            System.out.print(row8[j]);
        }
        System.out.println(" ");
        for (int j = 0; j < row9.length; j++){
            System.out.print(row9[j]);
        }
        System.out.println(" ");


    }
}


