public class Player {
    String Name;

}
