import java.util.Arrays;
import java.util.Scanner;

public class Runner {
    Scanner sc = new Scanner(System.in);
   // String input = sc.next();

    public static void main(String[] args){
    Board b = new Board();
    Scanner sc = new Scanner(System.in);
    String input = sc.next();


        for(int i = 0; i < 1; i++){
            System.out.println(Arrays.toString(b.row0) + "\n" + Arrays.toString(b.row1) + "\n" +Arrays.toString(b.row2) + "\n" +Arrays.toString(b.row3) + "\n" +Arrays.toString(b.row4) + "\n" +Arrays.toString(b.row5) + "\n" +Arrays.toString(b.row6) + "\n" +Arrays.toString(b.row7) + "\n" +Arrays.toString(b.row8) + "\n" +Arrays.toString(b.row9) + "\n" + Arrays.toString(b.row10));

        }


        if(input == "a"){
            System.out.println("you have selected row a, please pick a tile 1-10 to shoot");
        }

    }
}
