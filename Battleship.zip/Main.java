/*
USE FULLSCREEN FOR BEST EXPERIENCE

*/
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    Scanner sc = new Scanner(System.in);
   // String input = sc.next();

    public static void main(String[] args){
    Board b = new Board();
    Board c = new Board();
    Scanner sc = new Scanner(System.in);
    String prompt1 = "Pick a spot to place the ship || example- a (press enter) 5";



// title screen, must be opened in full screen or it looks stupid and broken
      System.out.println(
"oo____oo____oo_________ooo_________________________________________oo_______________ooooooo___________oo_____oo____ooo__________________oo_______oo____________oo_" + "\n" +
"oo____oo____oo__ooooo___oo____ooooo___ooooo__oo_oo_oo___ooooo______oo_____ooooo_____oo____oo__ooooo___oo_____oo_____oo____ooooo___oooo__oo_ooo__________ooooo__oo_" + "\n" + 
"oo____oo____oo_oo____o__oo___oo___oo_oo___oo_ooo_oo__o_oo____o____oooo___oo___oo____oooooooo_oo___oo_oooo___oooo____oo___oo____o_oo___o_ooo___o__oo_____o___oo_oo_" + "\n" +
"_oo__oooo__oo__ooooooo__oo___oo______oo___oo_oo__oo__o_ooooooo_____oo____oo___oo____oo____oo_oo___oo__oo_____oo_____oo___ooooooo___oo___oo____o__oo____oo___oo_oo_" + "\n" +
"__oooo__oooo___oo_______oo___oo______oo___oo_oo__oo__o_oo__________oo__o_oo___oo____oo____oo_oo___oo__oo__o__oo__o__oo___oo______o___oo_oo____o__oo____oo___oo____" + "\n" +
"___oo____oo_____ooooo__ooooo__ooooo___ooooo__oo______o__ooooo_______ooo___ooooo_____ooooooo___oooo_o___ooo____ooo__ooooo__ooooo___oooo__oo____o_oooo_o_ooooo___oo_" + "\n" +
"_____________________________________________________________________________________________________________________________________________________oooo______oo_ " + "\n" );

        for(int i = 0; i < 1; i++){
            System.out.println(Arrays.toString(b.row0) + "\n" + Arrays.toString(b.row1) + "\n" +Arrays.toString(b.row2) + "\n" +Arrays.toString(b.row3) + "\n" +Arrays.toString(b.row4) + "\n" +Arrays.toString(b.row5) + "\n" +Arrays.toString(b.row6) + "\n" +Arrays.toString(b.row7) + "\n" +Arrays.toString(b.row8) + "\n" +Arrays.toString(b.row9) + "\n" + Arrays.toString(b.row10));

        }
          System.out.println("player one, do you want your 5 ship horozontal or vertical (h or v)");
        String tempinput = sc.next();
          System.out.println(prompt1);


    String yinput = sc.next();
    String xinput = sc.next();



        if(yinput == "a"){
            System.out.println("you have selected row a, please pick a tile 1-10 to shoot");
        }
      
    }
}
